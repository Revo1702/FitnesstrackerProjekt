﻿namespace FitnesstrackerMVVMSwitching.ViewModels
{
    internal interface INotifyOrioertyChanged
    {
    }
}